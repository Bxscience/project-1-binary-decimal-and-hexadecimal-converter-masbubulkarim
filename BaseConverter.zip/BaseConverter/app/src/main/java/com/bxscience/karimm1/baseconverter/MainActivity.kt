package com.bxscience.karimm1.baseconverter

import android.app.Activity
import android.content.Context
import android.graphics.PorterDuff
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.Fragment
import android.text.Editable
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.security.AccessController.getContext
import java.security.Key

class MainActivity : AppCompatActivity() {
    //fields
    var TAG = "BaseConverter"
    lateinit var decimal: EditText
    lateinit var binary: EditText
    lateinit var hex: EditText
    lateinit var clear: Button
    val array: MutableList<Char> = ArrayList<Char>()

    var decimalInput = 0
    var binaryInput = 0
    var hexInput = ""

    final var DECIMAL = "DECIMAL"
    final var BINARY = "BINARY"
    final var HEX = "HEX"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var letter: Char = 'g'
        while(letter <= 'z'){
            array.add(letter)
            ++letter
        }
        Log.d(TAG, "onCreate array filler: " + array)
        initTextViews()

    }


    fun initTextViews(){
        decimal=  findViewById<EditText>(R.id.decimalBox)
        binary = findViewById<EditText>(R.id.binaryBox)
        hex = findViewById<EditText>(R.id.hexBox)
        clear = findViewById<Button>(R.id.clear_btn)
        searchHandler()
        clearButton()
    }

    fun clearButton(){
        clear.setOnClickListener{
            clearAll()
        }
    }

    fun clearAll(){
        decimal.setText("")
        binary.setText("")
        hex.setText("")
    }

    fun Context.hideKeyboard(view: View) {
        val inputMethodManager = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun searchHandler() {
        //TODO: 19 digits perline
        var handled = false

        //decimal input
        decimal.setOnEditorActionListener { textView, i, keyEvent ->
            if(i == EditorInfo.IME_ACTION_DONE){
                Log.d(TAG, "decimalInput: entered worked")
                setValues(DECIMAL);
                hideKeyboard(decimal)
                true
            } else {
                false
            }
        }

        //binary input
        binary.setOnEditorActionListener { textView, i, keyEvent ->
            if(i == EditorInfo.IME_ACTION_DONE){
                Log.d(TAG, "binaryInput: entered worked")
                setValues(BINARY);
                hideKeyboard(binary)
                true
            } else {
                false
            }
        }


        //hex input
        hex.setOnEditorActionListener { textView, i, keyEvent ->
            if(i == EditorInfo.IME_ACTION_DONE){
                Log.d(TAG, "hexInput: entered worked")
                setValues(HEX);
                hideKeyboard(hex)
                true
            } else {
                false
            }
        }
    }

    fun setValues(inputType: String){
        if(inputType.equals(DECIMAL)){
            var temp = decimal.text.toString()

            if(!(temp.equals(""))){
                //dec set binary value
                var binaryVal = convertDecToBin(temp)
                binary.text = Editable.Factory.getInstance().newEditable(binaryVal)


                //dec set binary to hex
                var hexVal = convertDecToHex(temp)
                hex.text = Editable.Factory.getInstance().newEditable(hexVal)
                Log.d(TAG, "decimal input recived...other inputs set")
            } else {
                Toast.makeText(this, "No input recieved", Toast.LENGTH_SHORT).show()
            }

        }


        if(inputType.equals(BINARY)){
            var temp = binary.text.toString()
            //check if input is actually binary
            if(!(temp.equals(""))){
                if(checkBinary(temp)){
                    //binary set dec value
                    var decimalVal = convertBinaryToDecimal(temp)
                    decimal.text = Editable.Factory.getInstance().newEditable(decimalVal)

                    //binary set hex value
                    var hexVal = convertBinaryToHex(temp)
                    hex.text = Editable.Factory.getInstance().newEditable(hexVal)
                } else {
                    clearAll()
                    Toast.makeText(this, "Please input a proper Binary number", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "No input recieved", Toast.LENGTH_SHORT).show()
            }


        }

        if(inputType.equals(HEX)){
            var temp = hex.text.toString()

            if(!(temp.equals(""))){
                if(checkHex(temp)){
                    //hex to decimal
                    var decimalVal = convertHexToDec(temp)
                    decimal.text = Editable.Factory.getInstance().newEditable(decimalVal)

                    //hex to bin
                    var binaryVal = convertHexToBinary(temp)
                    binary.text = Editable.Factory.getInstance().newEditable(binaryVal)

                }
                else{
                    Toast.makeText(this, "Input was not a valid Hex number", Toast.LENGTH_LONG).show()
                    clearAll()
                }
            } else {
                Toast.makeText(this, "No input recieved", Toast.LENGTH_SHORT).show()
            }
        }
    }


    //decimal to other types________________________________________________________________________
    fun convertDecToBin(input: String): String{
        return input.toInt().toString(2)
    }

    fun convertDecToHex(input: String): String{
        val output = java.lang.Integer.toHexString(input.toInt())
        return output
    }
    //binary to other types_________________________________________________________________________
    fun convertBinaryToDecimal(input: String): String {
        var input2 = input.toLong()
        var decimalNumber = 0
        var i = 0
        var remainder: Long

        while (input2.toInt() != 0) {
            remainder = input2 % 10
            input2 /= 10
            decimalNumber += (remainder * Math.pow(2.0, i.toDouble())).toInt()
            ++i
        }
        return decimalNumber.toString()
    }

    fun convertBinaryToHex(input: String): String{
        return convertDecToHex(convertBinaryToDecimal(input))
    }

    //hex to other types____________________________________________________________________________
    fun convertHexToDec(input: String): String{
        return input.toLong(16).toString()
    }

    fun convertHexToBinary(input: String): String{
        return convertDecToBin(convertHexToDec(input))
    }


    //Check input methods___________________________________________________________________________
    fun checkBinary(input: String): Boolean{
        for(i in input){
            if(i.equals('1') || i.equals('1')){
                Log.d(TAG, "check Binary: " + i + " is valid binary digit")
            } else {
                Log.d(TAG, "check Binary: " + i + " is invalid binary digit")
                return false
            }
        }
        return true
    }

    fun checkHex(input: String): Boolean{
        for(i in input){
            for(j in array){
                if(i.toChar().equals(j)){
                    return false
                }
            }
        }
        return true
    }


}
